Wario Land 4: Parallel_World ver0.71
by beco(https://www.twitch.tv/beco)

[How to play]
Patch "Wario_Land_4_Parallel_World_ver0.71(US).bps" to a vanilla Wario Land 4(US) rom

[Progress]
Currently Entry Passage, Emerald Passage, Ruby Passage and Sapphire Passage are fully edited
The rest of levels (Topaz Passage and Golden Passage) are work in progress.

[Credits]
I'm able to hack the game thanks to WL4Editor, very useful and user-friendly tool
Huge appreciation for tool authors and Wario Land 4 hack community!

[Known issues]
- Wario's victory animation can be interrupted by taking a damage from the spikes after defeat a boss

[Update history]
2020/11/30 v0.71
- Fixed diamond counter bugs
- Made adjustments on some levels

2020/11/29 v0.7
- Edited Ruby Passage
- Added diamond counter
- Added the escape rooms in Sapphire level 4
- Made adjustments on some levels
- Custom CDs (Replaced with other game OST, not edited album title/art yet)
- S-hard available (for debugging purposes, will be disabled in ver1.0 release)

2020/08/18 v0.41
- Fixed some little stuff in Sapphire level 1

2020/08/18 v0.4
- Edited Sapphire Passage
- Added some custom graphics/musics

2020/05/20 v0.22
- Fixed the door settings in Room 8 of Emerald level 3

2020/05/20 v0.21
- Fixed the terrain in Room 12 of Emerald level 4

2020/05/20 v0.2 (Initial release)
- Edited Entry Passage and Emerald Passage
